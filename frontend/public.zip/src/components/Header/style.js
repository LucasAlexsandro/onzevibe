import styled from "styled-components";

export const HeaderContainer = styled.div`
  width: 100%;
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const HeaderNav = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;

  .header-logo {
    max-width: 200px;
    img {
      max-width: 100%;
    }
  }

  .header-items {
    .header-btn {
      width: 60px;
      height: 60px;
      background: #dfdfdf;
      border-radius: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2rem;
      color: var(--primary)
    }
  }
`;
