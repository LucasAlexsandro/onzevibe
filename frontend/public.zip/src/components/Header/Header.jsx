import React from "react";
import * as H from "./style";
import { Container } from "../../pages/Home/style";
import Logo from "../../assets/LOGOA.png";
import Btn from "../Buttons/Btn";
import { MdDashboard } from "react-icons/md";

export default function index() {
  return (
    <>
      <H.HeaderContainer>
        <Container>
          <H.HeaderNav>
            <div className="header-logo">
              <img src={Logo} />
            </div>
            <div className="header-items">
              <div className="header-btn">
                <MdDashboard/>
              </div>
            </div>
          </H.HeaderNav>
        </Container>
      </H.HeaderContainer>
    </>
  );
}
