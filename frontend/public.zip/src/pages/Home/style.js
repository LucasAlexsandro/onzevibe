import styled from "styled-components";

export const Container = styled.div`
  max-width: 120em;
  width: 100%;
  padding: 0 4%;
  margin: 0 auto;
`;
